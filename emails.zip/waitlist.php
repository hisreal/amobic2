<?php  $hide_navigation = true; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
        $propertyName = "Sand Cabin";
        $locationName = "Cape Town";
        $propertyType = "Luxury Cabin";
        $sleeps = "4 Guests";
        $priceFrom = "3500";
        $currency = "ZAR";
        $pageUrl = "https://www.amobic.com/property/sand-cabin";
        $imageUrl = "https://www.amobic.com/amobic/amobic/assets/img/property/sand-cabin-main.jpg";
        $metaTitle = "$propertyName in $locationName | $propertyType for $sleeps | Amobic";
        $metaDescription = "Book $propertyName, a curated $propertyType in $locationName for $sleeps. Enjoy refined interiors, prime location, seamless booking, and a memorable Amobic stay.";
    ?>

    <title><?php echo $metaTitle; ?></title>
    <meta name="description" content="<?php echo $metaDescription; ?>">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Amobic">
    <link rel="canonical" href="<?php echo $pageUrl; ?>">

    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo $metaTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDescription; ?>">
    <meta property="og:image" content="<?php echo $imageUrl; ?>">
    <meta property="og:url" content="<?php echo $pageUrl; ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Amobic">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $metaTitle; ?>">
    <meta name="twitter:description" content="<?php echo $metaDescription; ?>">
    <meta name="twitter:image" content="<?php echo $imageUrl; ?>">
       <link rel="icon" href="amobic/assets/img/images/favicon.png" type="image/png">

    <!-- libraries CSS -->
    <link rel="stylesheet" href="amobic/assets/icon/flaticon_real_estate.css">
    <link rel="stylesheet" href="amobic/assets/vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="amobic/assets/vendor/splide/splide.min.css">
    <link rel="stylesheet" href="amobic/assets/vendor/swiper/swiper-bundle.min.css">
    <link rel="stylesheet" href="amobic/assets/vendor/slim-select/slimselect.css">
    <link rel="stylesheet" href="amobic/assets/vendor/animate-wow/animate.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- custom CSS -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="amobic/assets/css/style.css?v=<?php echo filemtime('amobic/assets/css/style.css');?>">
    <!-- Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LodgingBusiness",
      "name": "<?php echo $propertyName; ?>",
      "description": "<?php echo $metaDescription; ?>",
      "url": "<?php echo $pageUrl; ?>",
      "image": "<?php echo $imageUrl; ?>",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "<?php echo $locationName; ?>",
        "addressCountry": "South Africa"
      },
      "priceRange": "<?php echo $currency . ' ' . $priceFrom; ?>",
      "brand": {
        "@type": "Brand",
        "name": "Amobic"
      },
      "amenityFeature": [
        {
          "@type": "LocationFeatureSpecification",
          "name": "Refined Interiors",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "Prime Location",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "Professional Management",
          "value": true
        }
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.amobic.com/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Properties",
          "item": "https://www.amobic.com/properties"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "<?php echo $propertyName; ?>",
          "item": "<?php echo $pageUrl; ?>"
        }
      ]
    }
    </script>
</head>

<body>
    <div class="preloader" id="preloader">
        <div class="loader"></div>
    </div>

    <!-- SIDEBAR SECTION START -->
    <div class="ul-sidebar">
        <!-- header -->
        <div class="ul-sidebar-header">
            <div class="ul-sidebar-header-logo">
                <a href="index.html">
                    <img src="amobic/assets/img/logo/amobic-logo-dark-full.png" alt="logo" class="logo">
                </a>
            </div>
            <!-- sidebar closer -->
            <button class="ul-sidebar-closer"><i class="flaticon-close"></i></button>
        </div>

        <div class="ul-sidebar-header-nav-wrapper d-block"></div>


        

    </div>
    <!-- SIDEBAR SECTION END -->

    <!-- SEARCH MODAL SECTION START -->
    <div class="ul-search-form-wrapper flex-grow-1 flex-shrink-0">
        <button class="ul-search-closer"><i class="flaticon-close"></i></button>

        <form action="#" class="ul-search-form">
            <div class="ul-search-form-right">
                <input type="search" name="search" id="ul-search" placeholder="Search Here">
                <button type="submit"><span class="icon"><i class="flaticon-search"></i></span></button>
            </div>
        </form>
    </div>
    <!-- SEARCH MODAL SECTION END -->

    <?php if (empty($hide_navigation)) : ?>
    <!-- HEADER SECTION START -->
    <header class="ul-header ul-header--home">
        <div class="ul-header-bottom">
            <div class="ul-header-bottom-wrapper">
                <!-- header left -->
                <div class="header-bottom-left">
                    <div class="logo-container">
                        <a href="index.php" class="d-inline-block"><img src="amobic/amobic/assets/img/logo/amobic-logo-white-full.png" alt="logo" class="logo"></a>
                    </div>
                </div>

                <!-- header nav -->
                <div class="ul-header-nav-wrapper">
                    <div class="to-go-to-sidebar-in-mobile">
                        <nav class="ul-header-nav">
                            <a href="index.php">Home</a>
                             <a href="homes.php">Explore Homes</a>
                             <a href="experiences.php">Experiences</a>
                             <a href="waitlist.php">Waitlist</a>
                           
                            <a href="landlords.php">For Landlords</a>
                             <a href="about.php">About</a>
                              <a href="faq.php">FAQs</a>
                               <a href="contact.php">Contact</a>
                                <a href="signup.php">Sign up</a>
                                 <!--<a href="">List Your Property</a>-->
                        </nav>
                    </div>
                </div>

                <!-- actions -->
                <div class="ul-header-actions">                  
                     <!-- <a href="signup.php" class="add-property-btn d-xxs-none"><i class="flaticon-user"></i> Sign Up</a>
                    <a href="#" class="add-property-btn d-xxs-none"><i class="flaticon-home"></i> Add Property</a> -->
                    <button class="ul-header-sidebar-opener d-lg-none">
                        <i class="flaticon-menu-button"></i>
                    </button>              
              </div>

                <!-- sidebar opener -->
                <div class="d-none">
                    <button class="ul-header-sidebar-opener"><i class="flaticon-menu-button"></i></button>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER SECTION END -->
    <?php endif; ?>


<main>
  <section class="amobic-waitlist-hero">
    <div class="amobic-waitlist-bg"></div>
    <div class="amobic-waitlist-overlay"></div>

    <div class="container">
      <div class="amobic-waitlist-hero-grid">
      <div class="amobic-waitlist-copy wow animate__fadeInUp">

       <h5 style="font-size: 1.5rem;" class="ul-banner-slide-title">Cape Town's Most Anticipated Property & Lifestyle Platform</h5>
        
       <span class="amobic-waitlist-kicker ">Cape Town Launch • September 2026</span>

          <span>
            <br>
            Be first. Early property owners and partners get guaranteed priority
            placement and reduced fees for Year 1.
          </span>

          <div class="amobic-waitlist-actions">
            <a href="property-owner.php" class="amobic-waitlist-primary">
              List Your Property
              <i class="bi bi-arrow-right"></i>
            </a>

            <a href="partner.php" class="amobic-waitlist-secondary">
              Partner With Us
            </a>
          </div>

          <div class="amobic-waitlist-proof">
            <i class="bi bi-shield-check"></i>
            <span>
              Already trusted by property owners in Atlantic Seaboard, Sea Point
              and Green Point.
            </span>
          </div>
        </div>

        <div class="amobic-waitlist-card wow animate__fadeInUp">
          <div class="amobic-waitlist-card-top">
            <span>Priority Access</span>
            <strong>Year 1</strong>
          </div>

          <h2>Join before the city-wide launch</h2>
          <p>
            Secure early visibility for your property, restaurant, spa, tour,
            or curated experience.
          </p>

          <div class="amobic-waitlist-card-list">
            <div>
              <i class="bi bi-stars"></i>
              <span>Reduced early partner fees</span>
            </div>
            <div>
              <i class="bi bi-geo-alt"></i>
              <span>Priority placement in Cape Town areas</span>
            </div>
            <div>
              <i class="bi bi-graph-up-arrow"></i>
              <span>Launch marketing exposure</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>


    <!-- FOOTER SECTION START -->
<footer class="ul-footer amobic-footer">
   
               

    <!-- footer bottom -->
    <div class="ul-footer-bottom amobic-footer-bottom">
        <div class="ul-container">
            <div class="amobic-footer-bottom-wrap">
                <p class="copyright-txt">
                    &copy; 2026 Amobic. All rights reserved.
                </p>

                <div class="amobic-footer-bottom-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Cookie Policy</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- FOOTER SECTION END -->
    <!-- libraries JS -->
    <script src="amobic/assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="amobic/assets/vendor/splide/splide.min.js"></script>
    <script src="amobic/assets/vendor/splide/splide-extension-auto-scroll.min.js"></script>
    <script src="amobic/assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="amobic/assets/vendor/slim-select/slimselect.min.js"></script>
    <script src="amobic/assets/vendor/animate-wow/wow.min.js"></script>
    <script src="amobic/assets/vendor/splittype/index.min.js"></script>
    <script src="amobic/assets/vendor/mixitup/mixitup.min.js"></script>
    <script src="amobic/assets/vendor/fslightbox/fslightbox.js"></script>

    <!-- custom JS -->
    <script src="amobic/assets/js/main.js"></script>
    <script src="amobic/assets/js/tab.js"></script>
    <script src="amobic/assets/js/custom.js"></script>
    <script src="amobic/assets/js/form-auth.js"></script>


  <!--const openSidebar = document.getElementById("openSidebar");
const closeSidebar = document.getElementById("closeSidebar");
const mobileSidebar = document.getElementById("mobileSidebar");
const sidebarOverlay = document.getElementById("sidebarOverlay");

openSidebar.addEventListener("click", function () {
  mobileSidebar.classList.add("active");
  sidebarOverlay.classList.add("active");
});

closeSidebar.addEventListener("click", function () {
  mobileSidebar.classList.remove("active");
  sidebarOverlay.classList.remove("active");
});

sidebarOverlay.addEventListener("click", function () {
  mobileSidebar.classList.remove("active");
  sidebarOverlay.classList.remove("active");
});-->

</body>

</html>